import React from 'react';
import background from './background_3.png';

class AboutPage extends React.Component{
   render(){
    return (
        <nav className="nav" >
          <div className="container">
            <img  src={background} />
          </div>
        </nav>
      );
   }
}

export default AboutPage;